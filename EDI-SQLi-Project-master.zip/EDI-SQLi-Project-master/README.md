# EDI-SQLi-Project

A project for the EDI Course. University of Pavia, 2020.<br><br>
Authors: 
  - Caronte Gianluca
  - Fecchio Andrea
  - Giura Riccardo
  - Inchingolo Michele
  - Mariani Lorenzo
  - Mono Bill

insert into users values ('mario.rossi@email.com', 'ciao', 'Mario','Rossi', 'Ferrero International S.A.');
insert into users values ('luigi.verdi@email.com', 'ciao', 'Luigi','Verdi', 'Ferrero International S.A.');

insert into users values ('giovanni.bianchi@email.com', 'ciao', 'Giovanni','Bianchi', 'The Coca-Cola Company');
insert into users values ('federico.azzurri@email.com', 'ciao', 'Federico','Azzurri', 'The Coca-Cola Company');

insert into aziende values ('Ferrero International S.A.','20000000001');
insert into aziende values ('The Coca-Cola Company','20000000002');

"""
Main routine of the fuzzer

"""

from fuzzer import main


__all__ = ('main',)


if __name__ == '__main__':
    main()
